# Signature Recognition

CNN-based signature image classification.

## Install

Use Python 3.10 or 3.11:

```bash
pip install -r requirements.txt
```

## Add training images

Put images into one folder per class/person:

```text
data/
└── train/
    ├── Person1/
    │   ├── signature1.png
    │   └── signature2.png
    └── Person2/
        ├── signature1.png
        └── signature2.png
```

Add labelled images for at least two classes, then run:

```bash
python signature_recognition.py
```

The model is saved as `signature_model.keras`; class labels are saved as `classes.npy`.

This is a demonstration classifier, not a secure identity-verification system.
