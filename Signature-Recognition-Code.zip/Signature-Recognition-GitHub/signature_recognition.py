import os
import numpy as np
import pandas as pd
import cv2
import tensorflow as tf

from sklearn.preprocessing import LabelEncoder
from tensorflow.keras import layers, models

IMG_SIZE = (160, 190)


def load_data(folder):
    images, labels = [], []

    for label in os.listdir(folder):
        path = os.path.join(folder, label)
        if not os.path.isdir(path):
            continue

        for file in os.listdir(path):
            img = cv2.imread(os.path.join(path, file))
            if img is None:
                continue
            img = cv2.resize(img, IMG_SIZE) / 255.0
            images.append(img)
            labels.append(label)

    return np.array(images), np.array(labels)


def create_model(number_of_classes):
    model = models.Sequential([
        layers.Input(shape=(190, 160, 3)),
        layers.Conv2D(64, (3, 3), activation="relu"),
        layers.MaxPooling2D(2, 2),
        layers.Conv2D(96, (3, 3), activation="relu"),
        layers.MaxPooling2D(2, 2),
        layers.Conv2D(128, (3, 3), activation="relu"),
        layers.MaxPooling2D(2, 2),
        layers.Flatten(),
        layers.Dense(1024, activation="relu"),
        layers.Dropout(0.5),
        layers.Dense(number_of_classes, activation="softmax")
    ])

    model.compile(
        optimizer="adam",
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"]
    )
    return model


def main():
    training_folder = os.path.join("data", "train")
    if not os.path.isdir(training_folder):
        raise FileNotFoundError("Create data/train and add class folders.")

    X, y = load_data(training_folder)
    if len(X) == 0:
        raise ValueError("No readable training images were found.")

    encoder = LabelEncoder()
    y = encoder.fit_transform(y)

    if len(encoder.classes_) < 2:
        raise ValueError("At least two signature classes are required.")

    model = create_model(len(encoder.classes_))
    model.fit(
        X, y,
        epochs=10,
        batch_size=32,
        validation_split=0.2 if len(X) >= 5 else 0.0
    )

    model.save("signature_model.keras")
    np.save("classes.npy", encoder.classes_)
    print("Model training completed!")


if __name__ == "__main__":
    main()
